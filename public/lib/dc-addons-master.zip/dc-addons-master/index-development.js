module.exports = require('./src/scripts/server');
