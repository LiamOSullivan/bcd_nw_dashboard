module.exports = require('./dist/server/dc-server');
