module.exports = {
    test: {
        configFile: 'karma.conf.js',
    },
    build: {
        configFile: 'karma.conf.js',
        singleRun: true,
    }
};
